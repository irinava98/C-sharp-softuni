﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{

	public abstract class Food
	{
		public int Quantity { get; set; }

		protected Food(int quantity)
		{
			Quantity = quantity;
		}

	}

	public class Vegetable : Food
	{
		public Vegetable(int quantity) : base(quantity)
		{

		}
	}

	public class Fruit : Food
	{
		public Fruit(int quantity) : base(quantity)
		{

		}
	}

	public class Meat : Food
	{
		public Meat(int quantity) : base(quantity)
		{

		}
	}

	public class Seeds : Food
	{
		public Seeds(int quantity) : base(quantity)
		{

		}
	}

	public abstract class Animal
	{
		public string Name { get; set; }
		public double Weight { get; set; }
		public int FoodEaten { get; set; }

		protected Animal(string name, double weight)
		{
			Name = name;
			Weight = weight;

		}

		public abstract void Eat(Food food);
		public abstract string ProduceSound();
		public void ThrowInvalidOperationException(Animal animal, Food food)
		{
			throw new InvalidOperationException($"{animal.GetType().Name} does not eat {food.GetType().Name}!");
		}

	}

	public abstract class Bird : Animal
	{
		public Bird(string name, double weight, double wingSize) : base(name, weight)
		{
			WingSize = wingSize;
		}

		public double WingSize { get; set; }

		public override string ToString()
		{
			return $"{this.GetType().Name} [{this.Name}, {this.WingSize}, {this.Weight}, {this.FoodEaten}]";
		}
	}

	public class Owl : Bird
	{
		public Owl(string name, double weight, double wingSize) : base(name, weight, wingSize)
		{

		}
		public override void Eat(Food food)
		{
			if (!(food is Meat))
			{
				ThrowInvalidOperationException(this, food);

			}
			FoodEaten += food.Quantity;
			Weight += food.Quantity * 0.25;
		}

		public override string ProduceSound() => "Hoot Hoot";

	}

	public class Hen : Bird
	{
		public Hen(string name, double weight, double wingSize) : base(name, weight, wingSize)
		{

		}

		public override void Eat(Food food)
		{

			FoodEaten += food.Quantity;
			Weight += food.Quantity * 0.35;
		}

		public override string ProduceSound() => "Cluck";

	}

	public abstract class Mammal : Animal
	{
		public Mammal(string name, double weight, string livingRegion) : base(name, weight)
		{
			LivingRegion = livingRegion;
		}

		public string LivingRegion { get; set; }

	}

	public class Mouse : Mammal
	{
		public Mouse(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
		{

		}
		public override void Eat(Food food)
		{
			if (!(food is Vegetable || food is Fruit))
			{
				ThrowInvalidOperationException(this, food);
			}
			FoodEaten += food.Quantity;
			Weight += food.Quantity * 0.10;
		}

		public override string ProduceSound() => "Squeak";

		public override string ToString()
		{
			return $"{this.GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
		}

	}

	public class Dog : Mammal
	{
		public Dog(string name, double weight, string livingRegion) : base(name, weight, livingRegion)
		{

		}
		public override void Eat(Food food)
		{
			if (!(food is Meat))
			{
				ThrowInvalidOperationException(this, food);
			}
			FoodEaten += food.Quantity;
			Weight += food.Quantity * 0.40;
		}

		public override string ProduceSound() => "Woof!";

		public override string ToString()
		{
			return $"{this.GetType().Name} [{this.Name}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
		}

	}

	public abstract class Feline : Mammal
	{
		protected Feline(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion)
		{
			Breed = breed;
		}

		public string Breed { get; set; }

		public override string ToString()
		{
			return $"{this.GetType().Name} [{this.Name}, {this.Breed}, {this.Weight}, {this.LivingRegion}, {this.FoodEaten}]";
		}
	}

	public class Tiger : Feline
	{
		public Tiger(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion, breed)
		{

		}

		public override void Eat(Food food)
		{
			if (!(food is Meat))
			{
				ThrowInvalidOperationException(this, food);
			}
			FoodEaten += food.Quantity;
			Weight += food.Quantity;
		}

		public override string ProduceSound() => "ROAR!!!";

	}

	public class Cat : Feline
	{
		public Cat(string name, double weight, string livingRegion, string breed) : base(name, weight, livingRegion, breed)
		{

		}

		public override void Eat(Food food)
		{
			if (!(food is Meat || food is Vegetable))
			{
				ThrowInvalidOperationException(this, food);
			}
			FoodEaten += food.Quantity;
			Weight += food.Quantity * 0.30;
		}

		public override string ProduceSound() => "Meow";
	}

	public class StartUp
	{
		public static void Main(string[] args)
		{
			List<Animal> animals = new List<Animal>();


			string input = Console.ReadLine();
			while (input != "End")
			{
				string[] inputInfo = input.Split();
				string[] foodInfo = Console.ReadLine().Split();

				string animalType = inputInfo[0];
				string name = inputInfo[1];
				double weight = double.Parse(inputInfo[2]);

				string foodType = foodInfo[0];
				int quantity = int.Parse(foodInfo[1]);

				try
				{

					Animal animal = null;
					if (animalType == "Cat" || animalType == "Tiger")
					{
						string livingRegion = inputInfo[3];
						string breed = inputInfo[4];


						if (animalType == "Cat")
						{
							animal = new Cat(name, weight, livingRegion, breed);
						}
						else if (animalType == "Tiger")
						{
							animal = new Tiger(name, weight, livingRegion, breed);
						}


					}
					else if (animalType == "Owl" || animalType == "Hen")
					{
						double wingSize = double.Parse(inputInfo[3]);
						if (animalType == "Owl")
						{
							animal = new Owl(name, weight, wingSize);
						}
						else if (animalType == "Hen")
						{
							animal = new Hen(name, weight, wingSize);
						}

					}
					else if (animalType == "Mouse" || animalType == "Dog")
					{
						string livingRegion = inputInfo[3];
						if (animalType == "Mouse")
						{
							animal = new Mouse(name, weight, livingRegion);
						}
						else if (animalType == "Dog")
						{
							animal = new Dog(name, weight, livingRegion);
						}
					}

					Console.WriteLine(animal.ProduceSound());
					animals.Add(animal);

					Food food = null;

					if (foodType == "Fruit")
					{
						food = new Fruit(quantity);
					}
					else if (foodType == "Meat")
					{
						food = new Meat(quantity);
					}
					else if (foodType == "Seeds")
					{
						food = new Seeds(quantity);
					}
					else if (foodType == "Vegetable")
					{
						food = new Vegetable(quantity);
					}
					animal.Eat(food);


				}
				catch (Exception e)
				{
					Console.WriteLine(e.Message);
				}



				input = Console.ReadLine();
			}

			foreach (var animal in animals)
			{
				Console.WriteLine(animal);
			}
		}
	}
}