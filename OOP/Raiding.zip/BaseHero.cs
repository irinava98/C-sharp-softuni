﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public abstract class BaseHero
	{
		public string Name { get; set; }
		public abstract int Power { get; }

		protected BaseHero(string name)
		{
			Name = name;
		}

		public abstract string CastAbility();
	}

}