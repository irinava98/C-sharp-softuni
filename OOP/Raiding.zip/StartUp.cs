﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{

    public class StartUp
	{
		public static void Main(string[] args)
		{
			List<BaseHero> heroes = new List<BaseHero>();

			int n = int.Parse(Console.ReadLine());
			int count = 0;

			while (count < n)
			{
				string heroName = Console.ReadLine();
				string heroType = Console.ReadLine();

				if (heroType != "Druid" && heroType != "Paladin" && heroType != "Rogue" && heroType != "Warrior")
				{
					Console.WriteLine("Invalid hero!");
				}
				else
				{
					BaseHero hero = null;
					if (heroType == "Druid")
					{
						hero = new Druid(heroName);
						heroes.Add(hero);
					}
					else if (heroType == "Paladin")
					{
						hero = new Paladin(heroName);
						heroes.Add(hero);
					}
					else if (heroType == "Rogue")
					{
						hero = new Rogue(heroName);
						heroes.Add(hero);
					}
					else if (heroType == "Warrior")
					{
						hero = new Warrior(heroName);
						heroes.Add(hero);
					}
					count++;
				}
			}

			//Console.WriteLine(heroes.Count);

			int bossPower = int.Parse(Console.ReadLine());
			foreach (var hero in heroes)
			{
				Console.WriteLine(hero.CastAbility());
			}

			//Console.WriteLine(heroes.Sum(x=>x.Power));


			if (heroes.Sum(x => x.Power) >= bossPower)
			{
				Console.WriteLine("Victory!");
			}
			else
			{
				Console.WriteLine("Defeat...");
			}

		}
	}

}